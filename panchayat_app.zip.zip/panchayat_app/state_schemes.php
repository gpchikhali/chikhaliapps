<!DOCTYPE html>
<html lang="en">
<head>
    <title>State Schemes</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h2>State Schemes</h2>
    <p>Links to fill forms for all state government schemes.</p>
</body>
</html>

