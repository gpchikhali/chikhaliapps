<!DOCTYPE html>
<html lang="en">
<head>
    <title>Citizen Facilitation Centre</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h2>Citizen Facilitation Centre</h2>
    <p>Details about services provided by the Panchayat.</p>
</body>
</html>

