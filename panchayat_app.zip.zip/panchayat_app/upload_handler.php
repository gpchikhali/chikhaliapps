<?php
// upload_handler.php - Handles Video Uploads
session_start();
require 'config.php';

if (!isset($_SESSION['user'])) {
    echo "You must be logged in to upload videos.";
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["video"])) {
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["video"]["name"]);
    
    if (move_uploaded_file($_FILES["video"]["tmp_name"], $target_file)) {
        $sql = "INSERT INTO videos (user, file_path) VALUES ('{$_SESSION['user']}', '$target_file')";
        mysqli_query($conn, $sql);
        header("Location: upload_video.php?success=1");
        exit();
    } else {
        echo "Error uploading video.";
    }
}
?>

