<!DOCTYPE html>
<html lang="en">
<head>
    <title>1 to 33 Samples</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h2>Information about 1 to 33 Samples</h2>
    <p>Details of all the samples available in the Panchayat.</p>
</body>
</html>

