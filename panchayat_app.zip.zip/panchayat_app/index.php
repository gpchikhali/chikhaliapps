<?php
// index.php - Main Page
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panchayat Application</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="citizen_facilitation.php">Citizen Facilitation Centre</a></li>
            <li><a href="state_schemes.php">State Scheme Forms</a></li>
            <li><a href="samples.php">1 to 33 Samples</a></li>
            <li><a href="upload_video.php">Upload Video</a></li>
            <?php if(isset($_SESSION['user'])): ?>
                <li><a href="logout.php">Logout</a></li>
            <?php else: ?>
                <li><a href="login.php">Login</a></li>
                <li><a href="register.php">Register</a></li>
            <?php endif; ?>
        </ul>
    </nav>
    <h1>Welcome to Panchayat Application</h1>

    <?php
    if(isset($_SESSION['user'])) {
        echo "<p>Welcome, " . $_SESSION['user'] . "! You are logged in.</p>";
    } else {
        echo "<p>Please <a href='login.php'>login</a> or <a href='register.php'>register</a>.</p>";
    }
    ?>
</body>
</html>

